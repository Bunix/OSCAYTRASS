<?php 
include('session.php');
?>
<?php

if(isset($_POST["submit"]))
{

if (!$db) {
die("Connection failed: " . mysqli_connect_error());
header("refresh:0; url=club");
}
 $djoined = mysqli_real_escape_string($db, $_POST["djoined"]);
 $club_id = mysqli_real_escape_string($db, strtoupper($_POST["club_id"]));
 $fname = mysqli_real_escape_string($db, $_POST["fname"]);
 $address = mysqli_real_escape_string($db, $_POST["address"]);
 $coord_long = mysqli_real_escape_string($db, $_POST["coord_long"]);
 $coord_lat = mysqli_real_escape_string($db, $_POST["coord_lat"]);
 $loft = mysqli_real_escape_string($db, $_POST["loft"]);
 $contact = mysqli_real_escape_string($db, $_POST["contact"]);
 $email = mysqli_real_escape_string($db, $_POST["email"]);

 $encrypt_name = base64_encode($fname);
 $encrypt_club_id = base64_encode($club_id);
 $encrypt_address = base64_encode($address);
 $encrypt_coord_long = base64_encode($coord_long);
 $encrypt_coord_lat = base64_encode($coord_lat);
 $encrypt_loft = base64_encode($loft);
 $encrypt_contact = base64_encode($contact);
 $encrypt_email = base64_encode($email);

 $secret_code = base64_encode($fname.$club_id);

    $check=mysqli_query($db,"select * from club_members where member_club_id ='$encrypt_club_id'");
    $checkrows=mysqli_num_rows($check);

   if($checkrows>0) {
    echo "<script type= 'text/javascript'>alert('Club ID/ Member already exists in your records! Check your members list');</script>";
    header("refresh:0; url=add-club-member");
    } 
 else {
     try {
    $db->autocommit(FALSE); //turn on transactions
    $stmt = $db->prepare("INSERT INTO club_members (cid, member_club_id, name, address, coord_long, coord_lat, loft_name, secret_code, contact, email, d_joined) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("issssssssss", $login_club, $encrypt_club_id, $encrypt_name, $encrypt_address, $encrypt_coord_long, $encrypt_coord_lat, $encrypt_loft, $secret_code, $encrypt_contact, $encrypt_email, $djoined);   
    $stmt->execute();  
    $stmt->close();
    $db->autocommit(TRUE); //turn off transactions + commit queued queries
    echo "<script type= 'text/javascript'>alert('Record successfully saved!');</script>";  
    header("refresh:0; url=add-club-member");
  } catch(Exception $e) {
    $db->rollback(); //remove all queries from queue if error (undo)
    throw $e;
        }  
 
        }
    }  
?>