<?php
$salt = "&hdsuhjwehj63723gghsd632js723ghs63ghgd87162167893ghhdjksdhjkajsjskhdywujdhksywehchkskdywmdhasmcbcbhksa12414354s4s3as43as43a43d45x4c3544afd5442v5d4f3cx4v24vb2sd34f3dv35df44v3bhczghgdsgjhcvghnvxcjhsgdancvjhgshdmzzghsgmnz,ghsajjhgagdjhgsjgdhsajg;'hjhkdasjkhkjda123h23jk3jk$%&*^(*&Q&W*(HJHKXHK&^W*Q&WQKGHXJHQWUI^Q^WKHXQUW&*(QWHJKX&*QYWUKHXJhjxhjkxhzkhxzhkz";
?>