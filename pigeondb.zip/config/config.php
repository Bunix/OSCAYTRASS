<?php
 define('DB_SERVER', 'localhost');
 define('DB_USERNAME', 'CyGdb');
 define('DB_PASSWORD', 'UdSw08ZU49ufOC9D');
 define('DB_DATABASE', 'rpodb');
 
 $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

?>
